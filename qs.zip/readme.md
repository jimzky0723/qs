
## About this System

This is a Queuing System intended only for the Out-Patient Department of Talisay District Hospital. Please contact TDH Developer to have a copy of this system. 