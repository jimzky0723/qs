<?php
$station = session('section');
$sections = array(
    'pedia',
    'im',
    'surgery',
    'ob',
    'dental',
    'bite'
);

$count =  \App\Http\Controllers\PatientCtrl::getPendingList(3,'consultation');
?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $data = \App\Http\Controllers\PatientCtrl::getConsultationData($section);
            ?>
            <?php if($data): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title mb-3"><?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($section)); ?>: Now Serving...</strong>
                    </div>
                    <div class="card-body">
                        <div class="mx-auto d-block">
                            <div class="cardNum">
                                <?php echo e($data->num); ?>

                            </div>
                            <hr />
                            <h5 class="text-sm-center mt-2 mb-1"><?php echo e($data->fname); ?> <?php echo e($data->lname); ?></h5>
                            <div class="location text-sm-center">
                                <i class="fa fa-credit-card"></i> Hospital No.: <?php echo e(($data->hospitalNum==null) ? 'N/A': $data->hospitalNum); ?>

                                <br />
                                <i class="fa fa-stethoscope"></i> <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($data->section)); ?>

                            </div>
                        </div>
                        <hr>
                        <div class="card-text text-sm-center">
                            <a href="<?php echo e(url('patient/consultation/done/'.$data->id)); ?>" class="btn btn-success btn-sm btn-block">
                                <i class="fa fa-check"></i> Done
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title mb-3">Section: <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($section)); ?></strong>
                        <div class="pull-right">
                            <span class="badge badge-<?php echo e($section); ?> badge-success">Waiting: <?php echo e($count[$section]); ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="mx-auto d-block">
                            <div class="cardNum">
                                <small><i class="fa fa-user-plus"></i></small>
                            </div>
                            <hr />
                            <h5 class="text-sm-center mt-2 mb-1">Talisay District Hospital</h5>
                            <div class="location text-sm-center">
                                <i class="fa fa-user-times"></i> No patient <br />
                                please select new patient...
                            </div>
                        </div>
                        <hr>
                        <div class="card-text text-sm-center">
                            <a href="<?php echo e(url('patient/consultation/'.$section)); ?>" class="btn btn-warning btn-sm btn-block">
                                <i class="fa fa-arrow-right"></i> Next Patient
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
    sock.onopen = function() {
        console.log('<?php echo e($station); ?>');
        //pedia
        <?php if($station=='pedia'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('pedia'); ?>
        <?php if($data): ?>
            sock.send(JSON.stringify({
            section: 'pedia',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
            sock.send(JSON.stringify({
            section: 'pedia',
            number: '&nbsp;'
            }));
        <?php endif; ?>

        //internal medicine
        <?php elseif($station=='im'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('im'); ?>
        <?php if($data): ?>
        sock.send(JSON.stringify({
            section: 'im',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
        sock.send(JSON.stringify({
            section: 'im',
            number: '&nbsp;'
        }));
        <?php endif; ?>

        //surgery
        <?php elseif($station=='surgery'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('surgery'); ?>
        <?php if($data): ?>
        sock.send(JSON.stringify({
            section: 'surgery',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
        sock.send(JSON.stringify({
            section: 'surgery',
            number: '&nbsp;'
        }));
        <?php endif; ?>

        //ob
        <?php elseif($station=='ob'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('ob'); ?>
        <?php if($data): ?>
        sock.send(JSON.stringify({
            section: 'ob',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
        sock.send(JSON.stringify({
            section: 'ob',
            number: '&nbsp;'
        }));
        <?php endif; ?>

        //dental
        <?php elseif($station=='dental'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('dental'); ?>
        <?php if($data): ?>
        sock.send(JSON.stringify({
            section: 'dental',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
        sock.send(JSON.stringify({
            section: 'dental',
            number: '&nbsp;'
        }));
        <?php endif; ?>

        //animal bite
        <?php elseif($station=='bite'): ?>
        <?php $data = \App\Http\Controllers\PatientCtrl::getConsultationData('bite'); ?>
        <?php if($data): ?>
        sock.send(JSON.stringify({
            section: 'bite',
            number: '<?php echo e($data->num); ?>',
            priority: '<?php echo e($data->priority); ?>'
        }));
        <?php else: ?>
        sock.send(JSON.stringify({
            section: 'bite',
            number: '&nbsp;'
        }));
        <?php endif; ?>
        <?php endif; ?>
    };


    sock.onmessage = function(event) {
        var data = JSON.parse(event.data);
        console.log(data);
        if(data.channel=='addNumber' && data.section=='consultation'){
            $.get(
                '<?php echo e(url('patient/count/3/consultation')); ?>',
                function(data){
                    console.log(data);
                    $('.badge-pedia').html('Waiting: ' + data.pedia);
                    $('.badge-im').html('Waiting: ' + data.im);
                    $('.badge-surgery').html('Waiting: ' + data.surgery);
                    $('.badge-ob').html('Waiting: ' + data.ob);
                    $('.badge-dental').html('Waiting: ' + data.dental);
                    $('.badge-bite').html('Waiting: ' + data.bite);
                }
            );
        }
    };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>