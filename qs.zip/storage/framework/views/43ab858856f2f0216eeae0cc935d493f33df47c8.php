<?php
$status = session('status');
$section = array(
    'registration',
    'card',
    'vital',
    'pedia',
    'im',
    'surgery',
    'ob',
    'dental',
    'bite'
);

?>

<?php $__env->startSection('content'); ?>
    <div class="main-content container">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">User Priviledges
                    <div class="tools">
                        <form method="POST" action="<?php echo e(url('settings/access')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group mb-2">
                                <input type="text" class="form-control" name="keyword" placeholder="enter keyword . . ." value="<?php echo e(\Illuminate\Support\Facades\Session::get('accessKeyword')); ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary"><span class="s7-search"></span> Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel-body">
                    <?php if(count($data) > 0): ?>
                        <table class="table table-sm table-hover table-bordered table-striped">
                            <thead class="table-primary">
                            <tr>
                                <th>Complete Name</th>
                                <th class="text-center">Registration</th>
                                <th class="text-center">Card<br />Issuance</th>
                                <th class="text-center">Vital<br />Signs</th>
                                <th class="text-center">Pedia</th>
                                <th class="text-center">IM</th>
                                <th class="text-center">Surgery</th>
                                <th class="text-center">OB</th>
                                <th class="text-center">Dental</th>
                                <th class="text-center">Animal<br />Bite</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $access = \App\Http\Controllers\AdminCtrl::getAccess($row->id);
                                ?>
                                <tr>
                                    <td>
                                        <a href="#updateInfo" data-toggle="modal" data-id="<?php echo e($row->id); ?>">
                                            <i class="fa fa-edit"></i>
                                            <?php echo e($row->lname); ?>, <?php echo e($row->fname); ?>

                                        </a>
                                    </td>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="text-center">
                                            <?php if($access->$row): ?>
                                                <i class="fa fa-check text-success"></i>
                                            <?php else: ?>
                                                <i class="fa fa-times text-danger"></i>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr />
                        <div class="text-center">
                            <?php echo e($data->links()); ?>

                        </div>
                    <?php else: ?>
                        <div role="alert" class="alert alert-warning alert-dismissible">
                            <div class="icon"><span class="s7-attention"></span></div>
                            <div class="message"><strong>Warning!</strong> No user found.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="updateInfo" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(url('settings/access/update')); ?>" class="form-horizontal">
                    <div class="modal-body">
                        <h3 class="title-header">
                            Access Level
                        </h3>
                        <br />
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="userId" id="userId" value="" />
                        <table class="table table-bordered table-access switchArea">
                            <tr>
                                <td>Loading...</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-block btn-sm btn-success">
                            <i class="fa fa-check"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });

    </script>

    <script>
        $('a[href="#updateInfo"]').on('click',function(){
            var id = $(this).data('id');
            $('#userId').val(id);
            var content = '';
                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var equiv = "<?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row)); ?>";
            var section = "<?php echo e($row); ?>";

            content += '<tr>\n' +
                '<td class="text-right bg-dark" style="color:#fff;">'+equiv+'</td>\n' +
                '<td class="text-center">\n' +
                '     <label class="switch switch-text switch-primary" id="'+section+'">\n' +
                '        <input type="checkbox" class="switch-input" checked="true" name="<?php echo e($row); ?>">\n' +
                '       <span data-on="On" data-off="Off" class="switch-label"></span>\n' +
                '        <span class="switch-handle"></span>\n' +
                '    </label>\n' +
                '    </td>\n' +
                ' </tr>';
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('.switchArea').html(content);

            $.get(
                "<?php echo e(url('settings/access/get')); ?>/"+id,
                function (data){
                    var content = '';
                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        var val = data<?php echo e('.'.$row); ?>;
                        var equiv = "<?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row)); ?>";
                        var stats = $('checkbox[name="<?php echo e($row); ?>"]');

                    content += '<tr>' +
                        '<td class="text-right bg-dark" style="color:#fff;">'+equiv+'</td>' +
                        '<td class="text-center">' +
                        '<div class="switch-button switch-button-yesno">';
                    if(val==0){
                        content += '<input type="checkbox" name="<?php echo e($row); ?>" id="<?php echo e($row); ?>">';
                    }else{
                        content += '<input type="checkbox" checked name="<?php echo e($row); ?>" id="<?php echo e($row); ?>">'
                    }
                    content += '<span><label for="<?php echo e($row); ?>"></label></span>\n' +
                        '    </div>' +
                        '</td>' +
                        '</tr>';

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    $('.switchArea').html(content);
                }
            );
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>