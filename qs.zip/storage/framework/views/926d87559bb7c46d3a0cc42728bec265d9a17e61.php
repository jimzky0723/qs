<?php
    $status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <div class="main-content container">
        <?php if($status=='saved'): ?>
            <div role="alert" class="alert alert-success alert-dismissible">
                <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
                <div class="icon"><span class="s7-check"></span></div>
                <div class="message"><strong>Success!</strong> 1 news added.</div>
            </div>
        <?php elseif($status=='urlUpdated'): ?>
            <div role="alert" class="alert alert-success alert-dismissible">
                <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
                <div class="icon"><span class="s7-check"></span></div>
                <div class="message"><strong>Success!</strong> Server IP address successfully updated.</div>
            </div>
        <?php elseif($status=='updated'): ?>
            <div role="alert" class="alert alert-success alert-dismissible">
                <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
                <div class="icon"><span class="s7-check"></span></div>
                <div class="message"><strong>Success!</strong> News successfully updated.</div>
            </div>
        <?php elseif($status=='deleted'): ?>
            <div role="alert" class="alert alert-info alert-dismissible">
                <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
                <div class="icon"><span class="s7-info"></span></div>
                <div class="message"><strong>Success!</strong> News successfully removed.</div>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-3">
                <?php if($info): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading panel-heading-divider">
                            Update News
                            <a class="btn btn-success btn-xs pull-right" style="color: #fff;" href="<?php echo e(url('settings/parameters')); ?>">
                                +
                            </a>

                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(url('settings/news/update')); ?>" method="post" data-parsley-validate="" novalidate="">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="currentId" value="<?php echo e($info->id); ?>" />
                                <div class="form-group">
                                    <label>Content</label>
                                    <textarea class="form-control" required name="description" placeholder="Content of news here..." style="resize: none;line-height:20px !important;" rows="7"><?php echo $info->content; ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="text-right">
                                            <button type="submit" class="btn btn-space btn-block btn-primary">Update</button>
                                            <button type="button" class="btn btn-space btn-block btn-danger md-trigger btn-cancel" data-modal="modal-remove" data-link="<?php echo e(url('settings/news/delete/'.$info->id)); ?>">Delete</button>
                                        </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="panel panel-default">
                        <div class="panel-heading panel-heading-divider">Add News</div>
                        <div class="panel-body">
                            <form action="<?php echo e(url('settings/news/save')); ?>" method="post" data-parsley-validate="" novalidate="">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Content</label>
                                    <textarea class="form-control" required name="description" placeholder="Content of news here..." style="resize: none;line-height:20px !important;" rows="7"></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="text-right">
                                            <button type="submit" class="btn btn-space btn-block btn-primary">Add News</button>
                                        </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-9">
                <div class="panel panel-default">
                    <div class="panel-heading">System Parameters</div>
                    <div class="panel-body">
                        <form method="post" action="<?php echo e(url('settings/parameters/url/update')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="input-group mb-2">
                            <div class="input-group-prepend"><span class="input-group-text">Server IP Address</span></div>
                            <input type="text" placeholder="192.168.1.0" name="url" class="form-control" value="<?php echo e($url); ?>">

                            <button class="btn btn-success" type="submit">
                                <i class="fa fa-check"></i> Update
                            </button>
                        </div>
                        <small class="text-muted">
                            (Example: ws://localhost:5001)
                        </small>
                        </form>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">News List</div>
                    <div class="panel-body">
                        <?php if(count($data) > 0): ?>
                            <table class="table table-sm table-hover table-bordered table-striped">
                                <thead class="table-primary">
                                <tr>
                                    <th width="20%">Date Created</th>
                                    <th>Content</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(url('settings/parameters/news/'.$row->id)); ?>">
                                            <?php echo e(date('M d, Y h:i A',strtotime($row->created_at))); ?></td>
                                        </a>
                                    <td>
                                        <?php echo $row->content; ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr />
                            <div class="text-center">
                                
                            </div>
                        <?php else: ?>
                            <div role="alert" class="alert alert-warning alert-dismissible">
                                <div class="icon"><span class="s7-attention"></span></div>
                                <div class="message"><strong>Warning!</strong> No news yet!</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('resources/tdh/')); ?>/lib/parsley/parsley.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
            $('form').parsley();
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });

    </script>
    <?php echo $__env->make('script.cancel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>