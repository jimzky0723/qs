<?php
    $station = session('station');
?>

<?php $__env->startSection('content'); ?>
    <style>
        .panel-heading .badge {
            float: right;
            font-size: .946154rem;
            padding: 4px 7px;
        }
        .cardNum {
            text-align: center;
            font-size: 140px;
            line-height: 150px;
            background: #2cc185;
            padding: 20px;
            color: #fff;
            letter-spacing: -8px;
        }
        .emptyNum {
            text-align: center;
            font-size: 150px;
            line-height: 150px;
            background: #e6e6e6;
            padding: 20px;
            color: #000;
        }

    </style>
    <div class="main-content container">
        <div class="row">
            <?php for($c=1;$c<=3;$c++): ?>
                <?php
                $data = \App\Http\Controllers\PatientCtrl::getVitalData($c);
                ?>
                <?php if($data): ?>
                    <div class="col-md-4">
                        <div class="panel panel-border-color panel-border-color-primary">
                            <div class="panel-heading panel-heading-divider">
                                Vital <?php echo e($c); ?> : Now Serving...
                            </div>
                            <div class="panel-body">
                                <div class="cardNum">
                                    <small><?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($data->section)); ?><?php echo e($data->num); ?></small>
                                </div>
                                <hr />
                                <h5 class="text-sm-center"><strong><?php echo e($data->lname); ?>, <?php echo e($data->fname); ?></strong></h5>
                                <div class="location text-sm-center">
                                    <strong>Hospital # :</strong> <?php echo e(($data->hospitalNum==null) ? 'N/A': $data->hospitalNum); ?><br />
                                    <strong>Section :</strong> <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($data->section)); ?>

                                </div>
                                <hr>
                                <div class="row">
                                    <a href="<?php echo e(url('patient/vital/done/'.$c.'/'.$data->id)); ?>" class="btn btn-success btn-sm col-sm-4">
                                        <i class="fa fa-check"></i> Done
                                    </a>
                                    <a href="#" data-link="<?php echo e(url('patient/vital/cancel/'.$c.'/'.$data->id)); ?>" data-modal="modal-cancel" class="btn btn-warning btn-sm col-sm-4  md-trigger btn-cancel">
                                        <i class="fa fa-times"></i> Cancel
                                    </a>
                                    <a href="<?php echo e(url('patient/vital/notify/'.$c.'/'.$data->id)); ?>" class="btn btn-info btn-sm col-sm-4">
                                        <i class="fa fa-bell"></i> Notify
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-md-4">
                        <div class="panel panel-border-color panel-border-color-info">
                            <div class="panel-heading panel-heading-divider">
                                Vital <?php echo e($c); ?>

                                <span class="badge badge-info badge-<?php echo e($c); ?>">Waiting: <?php echo e(\App\Http\Controllers\PatientCtrl::getPendingList(2,'',$c)); ?></span>
                            </div>
                            <div class="panel-body">
                                <div class="emptyNum">
                                    <small><i class="fa fa-user-plus"></i></small>
                                </div>
                                <hr />
                                <h5 class="text-sm-center">Talisay District Hospital</h5>
                                <div class="location text-sm-center">
                                    <i class="fa fa-user-times"></i> No patient <br />
                                    please select new patient...
                                </div>
                                <hr>
                                <a href="<?php echo e(url('patient/vital/next/'.$c.'/0')); ?>" class="btn btn-info btn-sm btn-block">
                                    <i class="fa fa-arrow-right"></i> Next Patient
                                </a>
                            </div>

                        </div>
                    </div>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });
    </script>

    <script>
        sock.onopen = function() {
            <?php if($station==1): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(1); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital1',
                    number: '<?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($data->section)); ?><?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital1',
                    number: '&nbsp;'
                }));
                sock.send(JSON.stringify({
                    section: 'consultation',
                    channel: 'addNumber'
                }));
                <?php endif; ?>
            }
            <?php elseif($station==2): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(2); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital2',
                    number: '<?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($data->section)); ?><?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital2',
                    number: '&nbsp;'
                }));
                sock.send(JSON.stringify({
                    section: 'consultation',
                    channel: 'addNumber'
                }));
                <?php endif; ?>
            }
            <?php elseif($station==3): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(3); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital3',
                    number: '<?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($data->section)); ?><?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital3',
                    number: '&nbsp;'
                }));
                sock.send(JSON.stringify({
                    section: 'consultation',
                    channel: 'addNumber'
                }));
                <?php endif; ?>


            }
            <?php endif; ?>
        };

        sock.onmessage = function(event) {
            var data = JSON.parse(event.data);
            if(data.channel=='addNumber' && data.section=='vital'){
                $.get(
                    '<?php echo e(url('patient/count/2/')); ?>',
                    function(data){
                        console.log(data);
                        $('.badge-1').html('Waiting: ' + data);
                        $('.badge-2').html('Waiting: ' + data);
                    }
                );
                $.get(
                    '<?php echo e(url('patient/count/vital/ob')); ?>',
                    function(data){
                        console.log(data);
                        $('.badge-3').html('Waiting: ' + data);
                    }
                );
            }
        };
    </script>
    <?php echo $__env->make('script.cancel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>