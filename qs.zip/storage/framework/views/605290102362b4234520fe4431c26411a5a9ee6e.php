<?php
    $status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <style>
        .names  {
            text-transform: uppercase
        }
    </style>
    <div class="main-content container">
        <?php if($status=='save'): ?>
        <div role="alert" class="alert alert-success alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-check"></span></div>
            <div class="message"><strong>Success!</strong> 1 user added successfully.</div>
        </div>
        <?php elseif($status=='deleted'): ?>
        <div role="alert" class="alert alert-success alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-check"></span></div>
            <div class="message"><strong>Success!</strong> 1 user deleted successfully.</div>
        </div>
        <?php elseif($status=='duplicate'): ?>
        <div role="alert" class="alert alert-danger alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-close"></span></div>
            <div class="message"><strong>Duplicate username!</strong>  Please use different username.</div>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-3">
                <?php if($info): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading panel-heading-divider">
                            Update User
                            <a class="btn btn-success btn-xs pull-right" style="color: #fff;" href="<?php echo e(url('settings/user')); ?>">
                                +
                            </a>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(url('settings/user/update')); ?>" method="post" data-parsley-validate="" novalidate="">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="currentId" value="<?php echo e($info->id); ?>" />
                                <div class="form-group">
                                    <label>Profession</label>
                                    <select class="form-control custom-select" name="profession">
                                        <option value="nurse" <?php echo e(($info->profession=='nurse') ? 'selected':''); ?>>Nurse</option>
                                        <option value="doctor" <?php echo e(($info->profession=='doctor') ? 'selected':''); ?>>Doctor</option>
                                        <option value="staff" <?php echo e(($info->profession=='staff') ? 'selected':''); ?>>Staff</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input class="form-control" type="text" name="fname" placeholder="First Name" value="<?php echo e($info->fname); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input class="form-control" type="text" name="lname" placeholder="Last Name" value="<?php echo e($info->lname); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Access Level</label>
                                    <select class="form-control custom-select" name="access">
                                        <option value="standard" <?php echo e(($info->access=='standard') ? 'selected':''); ?>>Standard</option>
                                        <option value="admin"<?php echo e(($info->access=='admin') ? 'selected':''); ?>>Admin</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="form-control" type="text" name="username" placeholder="Username" value="<?php echo e($info->username); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" name="password" placeholder="Unchanged">
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="form-control custom-select" name="status">
                                        <option value="1" <?php echo e(($info->status=='1') ? 'selected':''); ?>>Active</option>
                                        <option value="0" <?php echo e(($info->status=='0') ? 'selected':''); ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="text-right">
                                            <button type="submit" class="btn btn-space btn-block btn-primary">Update</button>
                                            <button type="button" class="btn btn-space btn-block btn-danger md-trigger btn-cancel" data-modal="modal-remove" data-link="<?php echo e(url('settings/user/delete/'.$info->id)); ?>">Delete</button>
                                        </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="panel panel-default">
                        <div class="panel-heading panel-heading-divider">Add User</div>
                        <div class="panel-body">
                            <form action="<?php echo e(url('settings/user/save')); ?>" method="post" data-parsley-validate="" novalidate="">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Profession</label>
                                    <select class="form-control custom-select" name="profession">
                                        <option value="nurse">Nurse</option>
                                        <option value="doctor">Doctor</option>
                                        <option value="staff">Staff</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input class="form-control" type="text" name="fname" placeholder="First Name" required>
                                </div>
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input class="form-control" type="text" name="lname" placeholder="Last Name" required>
                                </div>
                                <div class="form-group">
                                    <label>Profession</label>
                                    <select class="form-control custom-select" name="access">
                                        <option value="standard">Standard</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="form-control" type="text" name="username" placeholder="Username" required>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" name="password" placeholder="Password" required>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="form-control custom-select" name="status">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="text-right">
                                            <button type="submit" class="btn btn-space btn-block btn-primary">Save</button>
                                        </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-9">
                <div class="panel panel-default">
                    <div class="panel-heading">User List
                        <div class="tools">
                            <form method="POST" action="<?php echo e(url('settings/user')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="input-group mb-2">
                                    <input type="text" class="form-control" name="keyword" placeholder="enter keyword . . ." value="<?php echo e(\Illuminate\Support\Facades\Session::get('userKeyword')); ?>">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary"><span class="s7-search"></span> Search</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if(count($data) > 0): ?>
                        <table class="table table-sm table-hover table-bordered table-striped">
                            <thead class="table-primary">
                            <tr>
                                <th>Username</th>
                                <th class="number">Profession</th>
                                <th class="number">First Name</th>
                                <th class="number">Last Name</th>
                                <th class="number">Access</th>
                                <th class="number">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(url('settings/user/update/' . $row->id)); ?>">
                                            <span class="s7-note"></span> <?php echo e($row->username); ?>

                                        </a>
                                    </td>
                                    <td class="number names"><?php echo e($row->profession); ?></td>
                                    <td class="number names"><?php echo e($row->fname); ?></td>
                                    <td class="number names"><?php echo e($row->lname); ?></td>
                                    <td class="number names"><?php echo e($row->access); ?></td>
                                    <td class="number">
                                        <font class="<?php echo e(($row->status==1) ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo e(($row->status==1) ? 'Active' : 'Inactive'); ?>

                                        </font>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr />
                        <div class="text-center">
                            <?php echo e($data->links()); ?>

                        </div>
                        <?php else: ?>
                            <div role="alert" class="alert alert-warning alert-dismissible">
                                <div class="icon"><span class="s7-attention"></span></div>
                                <div class="message"><strong>Warning!</strong> No user found.</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('script.cancel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(url('resources/tdh/')); ?>/lib/parsley/parsley.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
            $('form').parsley();

            
            $.get("<?php echo e(url('api/get/data')); ?>",function(data){
                //var tmp = jQuery.parseJSON(data);
                console.log(data);
            });
            
                
            
                
            
            var data = [
                [1, 25],
                [2, 10],
                [3, 10],
                [4, 15],
                [5, 0],
                [6, 47],
                [7, 65],
                [8, 10]
            ];
            console.log(data);
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>