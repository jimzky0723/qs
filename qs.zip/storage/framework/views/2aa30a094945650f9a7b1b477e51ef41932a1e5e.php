<?php
    $status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <style>
        .table {
            text-transform: uppercase;
        }
        .title-header {
            font-weight: normal;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }
        .modal { overflow: auto !important; }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="top-campaign">
                <?php if($status=='incorrentPassword'): ?>
                    <div class="alert alert-danger">
                        <i class="fa fa-times"></i> Incorrect Password!
                    </div>
                <?php endif; ?>
                <?php if($status=='updated'): ?>
                    <div class="alert alert-success">
                        <i class="fa fa-check"></i> User updated successfully!
                    </div>
                <?php endif; ?>
                <h3 class="title-3 m-b-30">
                    User Accounts
                    <div class="pull-right">
                        <form method="POST" action="<?php echo e(url('settings/user')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <input type="text" name="keyword" placeholder="enter keyword . . ." class="form-control" value="<?php echo e(\Illuminate\Support\Facades\Session::get('userKeyword')); ?>">
                                <div class="input-group-btn">
                                    <button class="btn btn-success" type="submit">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </h3>
                <?php if(count($data) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-top-campaign table-striped" style="border:1px solid #ccc;">
                            <thead class="bg-dark" style="color:#fff;">
                            <tr>
                                <th>USERNAME</th>
                                <th>Profession</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Access</th>
                                <th class="text-center">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="#updateInfo" data-toggle="modal" data-id="<?php echo e($row->id); ?>">
                                        <i class="fa fa-edit"></i>
                                        <?php echo e($row->username); ?>

                                    </a>
                                </td>
                                <td><?php echo e($row->profession); ?></td>
                                <td><?php echo e($row->fname); ?></td>
                                <td><?php echo e($row->lname); ?></td>
                                <td><?php echo e($row->access); ?></td>
                                <td class="text-center">
                                    <font class="<?php echo e(($row->status==1) ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e(($row->status==1) ? 'Active' : 'Inactive'); ?>

                                    </font>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <br />
                    <div class="text-center">
                        <?php echo e($data->links()); ?>

                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        No user found!
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="updateInfo" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(url('settings/user/update')); ?>" class="form-horizontal">
            <div class="modal-body">
                <h3 class="title-header">
                    Update Info
                </h3>
                <br />
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="currentId" id="currentId" value="" />
                    <div class="form-group">
                        <label>Profession</label>
                        <select class="form-control" id="profession" name="profession" required>
                            <option value="staff">Staff</option>
                            <option value="nurse">Nurse</option>
                            <option value="doctor">Doctor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" required />
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" id="lname" name="lname" required />
                    </div>
                    <hr />
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" id="username" name="username" required />
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="unchanged..." />
                    </div>
                    <hr />
                    <div class="form-group">
                        <label>Access Level</label>
                        <select class="form-control" id="access" name="access" required>
                            <option value="standard">Standard</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" id="status" name="status" required>
                            <option value="0">Inactive</option>
                            <option value="1">Active</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-sm btn-success">
                    <i class="fa fa-edit"></i> Update
                </button>
                <button type="button" id="btnDeleteUser" class="btn btn-sm btn-danger">
                    <i class="fa fa-trash"></i> Delete
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteUser" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h3 class="title-header">
                    Delete User?
                </h3>
                <br />

                <center>
                    <div class="container">
                        <div class="row">
                            <a href="<?php echo e(url('settings/user/delete')); ?>" class="btn btn-lg btn-success col-sm-6">
                                <i class="fa fa-check"></i> Yes
                            </a>
                            <a id="cancelDelete" class="btn btn-lg btn-danger col-sm-6" style="color:#fff">
                                <i class="fa fa-times"></i> Cancel
                            </a>
                        </div>
                    </div>
                </center>
                <hr />
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('a[href="#updateInfo"]').on('click',function(){
         var id = $(this).data('id');
         $.get(
            "<?php echo e(url('settings/user/get/')); ?>/"+id,
            function(data){
                $('#currentId').val(data.id);
                $('#username').val(data.username);
                $('#fname').val(data.fname);
                $('#lname').val(data.lname);
                $('#profession').val(data.profession);
                $('#access').val(data.access);
                $('#status').val(data.status);
            }
         );
    });

    $('#btnDeleteUser').on('click',function(){
        $('#updateInfo').modal('hide');
        $('#deleteUser').modal('show');

    });

    $('#cancelDelete').on('click',function () {
        $('#deleteUser').modal('hide');
        $('#updateInfo').modal('show');

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>