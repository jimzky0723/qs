<?php
$status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <style>
        .table {
            text-transform: uppercase;
        }
    </style>
    <div class="row">
        <?php if($current): ?>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title mb-3">Now Serving</strong>
                </div>
                <div class="card-body">
                    <div class="mx-auto d-block">
                        <div class="cardNum">
                            <?php echo e($current->num); ?>

                        </div>
                        <hr />
                        <h5 class="text-sm-center mt-2 mb-1"><?php echo e($current->fname); ?> <?php echo e($current->lname); ?></h5>
                        <div class="location text-sm-center">
                            <i class="fa fa-credit-card"></i> Hospital No.: <?php echo e(($current->hospitalNum==null) ? 'N/A': $current->hospitalNum); ?>

                            <br />
                            <i class="fa fa-stethoscope"></i> <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($current->section)); ?>

                        </div>
                    </div>
                    <hr>
                    <div class="card-text text-sm-center">
                        <a href="<?php echo e(url('patient/card/done/'.$current->id)); ?>" class="btn btn-success btn-sm btn-block">
                            <i class="fa fa-check"></i> Done
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="top-campaign">
                <?php if($status=='added'): ?>
                    <div class="alert alert-success">
                        <i class="fa fa-check"></i> Successfully submitted!
                    </div>
                <?php elseif($status=='notAvailable'): ?>
                    <div class="alert alert-danger">
                        <i class="fa fa-times"></i> Error! Please complete transaction with your patient!
                    </div>
                <?php elseif($status=='pending'): ?>
                    <div class="alert alert-warning">
                        <i class="fa fa-refresh"></i> Added to 'Pending List'
                    </div>
                <?php elseif($status=='ready'): ?>
                    <div class="alert alert-info">
                        <i class="fa fa-check"></i> Accept new patient!
                    </div>
                <?php elseif($status=='error'): ?>
                    <div class="alert alert-danger">
                        <i class="fa fa-times"></i> Error in processing data!
                    </div>
                <?php endif; ?>
                <h3 class="title-3 m-b-30">Card Issuance</h3>
                <?php if(count($data) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-top-campaign table-striped" style="border:1px solid #ccc;">
                            <thead class="bg-dark" style="color:#fff;">
                            <tr>
                                <th class="text-center">Priority #</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Hospital #</th>
                                <th>Section</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center <?php echo e(($row->priority==1) ? 'text-success':''); ?>">
                                        <?php echo e($row->num); ?>

                                        <?php if($row->priority==1): ?>
                                            <span class="text-process"><i class="fa fa-arrow-up"></i></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($row->fname); ?></td>
                                    <td><?php echo e($row->lname); ?></td>
                                    <td><?php echo e($row->hospitalNum); ?></td>
                                    <td><?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row->section)); ?></td>
                                    <?php if($row->status=='ready'): ?>
                                        <td class="text-success">
                                            for verification
                                        </td>
                                    <?php else: ?>
                                        <td class="text-danger">
                                            <?php echo e($row->status); ?>

                                        </td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('patient/card/submit/'.$row->id)); ?>" class="btn btn-success btn-sm">
                                            <small><i class="fa fa-check"></i> Verified</small>
                                        </a>
                                        <a href="<?php echo e(url('patient/card/pending/'.$row->id)); ?>" class="btn btn-warning btn-sm">
                                            <small><i class="fa fa-refresh"></i> Pending</small>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        No patients available!
                    </div>
                <?php endif; ?>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if($current): ?>
    <script>
        sock.onopen = function() {
            sock.send(JSON.stringify({
                section: 'card',
                number: '<?php echo e($current->num); ?>',
                priority: '<?php echo e($current->priority); ?>'
            }));

            sock.send(JSON.stringify({
                channel: 'pending'
            }));
        };
    </script>
    <?php else: ?>
        <script>
            sock.onopen = function() {
                sock.send(JSON.stringify({
                    section: 'card',
                    number: '&nbsp;'
                }));

                sock.send(JSON.stringify({
                    section: 'vital',
                    channel: 'addNumber'
                }));

                sock.send(JSON.stringify({
                    channel: '<?php echo e($status); ?>'
                }));
            };
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>