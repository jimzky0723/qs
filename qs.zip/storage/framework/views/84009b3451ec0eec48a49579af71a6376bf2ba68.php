<?php
    $status = session('status');
?>

;

<style>
    .selection {
        text-align: center;
    }

    button.btn-main {
        width: 300px;
        height: 100px;
        margin: 10px 10px;
        font-size: 1.2em;
    }

    #modalNumber .modal-body {
        padding:0px;
        background-color: #4ed94c;
        text-align: center;
        color:#fff;
        padding: 30px;
    }
    #modalNumber .modal-body .number {
        font-size:150px;
        line-height: 140px;
    }
    #modalNumber .modal-body .title {
        font-size:20px;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="au-card m-b-30">
                <div class="au-card-inner">

                    <div class="selection">
                        <button type="button" class="btnPwd btn btn-main btn-dark" data-toggle="modal" data-target="#senior">Senior/PWD/Pregnant</button>
                        <button type="button" class="btnPedia btn btn-main btn-success">Pedia</button>
                        <br />
                        <button type="button" class="btnIm btn btn-main btn-info">Internal Medicine</button>
                        <button type="button" class="btnSurgery btn-main btn btn-primary">Surgery</button>
                        <br />
                        <button type="button" class="btnOb btn btn-main btn-danger">OB</button>
                        <button type="button" class="btnDental btn btn-main btn-warning">Dental</button>
                        <br />
                        <button type="button" class="btnBite btn btn-main btn-success">Animal Bite</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<input type="hidden" value="<?php echo e(csrf_token()); ?>" class="token" />

<!-- Modal -->
<div class="modal fade" id="senior" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="smallmodalLabel">Select Section</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body seniorSelection">
                <div class="form-group">
                    <button type="button" class="_im btn btn-info col-sm-12" data-dismiss="modal">Internal Medicine</button><br />
                </div>
                <div class="form-group">
                    <button type="button" class="_surgery btn btn-primary col-sm-12" data-dismiss="modal">Surgery</button><br />
                </div>
                <div class="form-group">
                    <button type="button" class="_ob btn btn-danger col-sm-12" data-dismiss="modal">OB</button><br />
                </div>
                <div class="form-group">
                    <button type="button" class="_dental btn btn-warning col-sm-12" data-dismiss="modal">Dental</button><br />
                </div>
                <div class="form-group">
                    <button type="button" class="_bite btn btn-success col-sm-12" data-dismiss="modal">Animal Bite</button><br />
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for ID -->
<div class="modal fade" id="modalNumber" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
               <span class="title">
                   Your number is:
               </span>
                <br />
                <span class="number">
                    0
                </span>
                <hr />
                <form method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="currentID" id="currentID" value="0" />
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">First Name</label>
                        <input name="fname" type="text" class="input-modal input-first form-control" autofocus autocomplete="off" required />
                    </div>
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Last Name</label>
                        <input name="lname" type="text" class="input-modal form-control" autocomplete="off" required />
                    </div>
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Date of Birth</label>
                        <input name="dob" type="date" class="input-modal form-control" />
                    </div>
                    <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Hospital #</label>
                        <input name="hospitalNum" type="text" class="input-modal form-control" autocomplete="off" />
                    </div>
                    <div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-dark btn-block">
                            <i class="fa fa-send fa-lg"></i>&nbsp;
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('script'); ?>
<script>
    var url = "<?php echo e(url('number/get')); ?>";
    var token = $('.token').val();
    console.log(token);

    $('.btnPedia').on('click',function(){
        getNumber('pedia',0);
    });
    $('.btnIm').on('click',function(){
        getNumber('im',0);
    });
    $('.btnSurgery').on('click',function(){
        getNumber('surgery',0);
    });
    $('.btnOb').on('click',function(){
        getNumber('ob',0);
    });
    $('.btnDental').on('click',function(){
        getNumber('dental',0);
    });
    $('.btnBite').on('click',function(){
        getNumber('bite',0);
    });

    $('._bite').on('click',function(){
        getNumber('bite',1);
    });
    $('._im').on('click',function(){
        getNumber('im',1);
    });
    $('._surgery').on('click',function(){
        getNumber('surgery',1);
    });
    $('._ob').on('click',function(){
        getNumber('ob',1);
    });
    $('._dental').on('click',function(){
        getNumber('dental',1);
    });

    function getNumber(section,priority)
    {
        $('.input-modal').val('');
        $('.input-first').focus();
        $('#senior').modal('hide');
        $('.btn').attr('disabled',true);
        $('#modalNumber .number').html('...');
        $.post(
            url,
            {
                section: section,
                priority: priority,
                _token: token
            },
            function(data){
                $('#modalNumber .number').html(data.num);
                $('#currentID').val(data.id);
                $('#modalNumber').modal({
                    backdrop: 'static',
                    keyboard: false
                });
                $('.btn').attr('disabled',false);
            }
        );
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>