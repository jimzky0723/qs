<?php
    $station = session('station');
?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php for($c=1;$c<=3;$c++): ?>
            <?php
                $data = \App\Http\Controllers\PatientCtrl::getVitalData($c);
            ?>
            <?php if($data): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title mb-3">Vital <?php echo e($c); ?>: Now Serving...</strong>
                    </div>
                    <div class="card-body">
                        <div class="mx-auto d-block">
                            <div class="cardNum">
                                <?php echo e($data->num); ?>

                            </div>
                            <hr />
                            <h5 class="text-sm-center mt-2 mb-1"><?php echo e($data->fname); ?> <?php echo e($data->lname); ?></h5>
                            <div class="location text-sm-center">
                                <i class="fa fa-credit-card"></i> Hospital No.: <?php echo e(($data->hospitalNum==null) ? 'N/A': $data->hospitalNum); ?>

                                <br />
                                <i class="fa fa-stethoscope"></i> <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($data->section)); ?>

                            </div>
                        </div>
                        <hr>
                        <div class="card-text text-sm-center">
                            <a href="<?php echo e(url('patient/vital/done/'.$c.'/'.$data->id)); ?>" class="btn btn-success btn-sm btn-block">
                                <i class="fa fa-check"></i> Done
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title mb-3">Vital <?php echo e($c); ?></strong>
                        <div class="pull-right">
                            <span class="badge badge-success">Waiting: <?php echo e(\App\Http\Controllers\PatientCtrl::getPendingList(2)); ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="mx-auto d-block">
                            <div class="cardNum">
                                <small><i class="fa fa-user-plus"></i></small>
                            </div>
                            <hr />
                            <h5 class="text-sm-center mt-2 mb-1">Talisay District Hospital</h5>
                            <div class="location text-sm-center">
                                <i class="fa fa-user-times"></i> No patient <br />
                                please select new patient...
                            </div>
                        </div>
                        <hr>
                        <div class="card-text text-sm-center">
                            <a href="<?php echo e(url('patient/vital/next/'.$c.'/0')); ?>" class="btn btn-warning btn-sm btn-block">
                                <i class="fa fa-arrow-right"></i> Next Patient
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        sock.onopen = function() {
            <?php if($station==1): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(1); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital1',
                    number: '<?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital1',
                    number: '&nbsp;'
                }));
                <?php endif; ?>
            }
            <?php elseif($station==2): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(2); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital2',
                    number: '<?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital2',
                    number: '&nbsp;'
                }));
                <?php endif; ?>
            }
            <?php elseif($station==3): ?>
            {
                <?php $data = \App\Http\Controllers\PatientCtrl::getVitalData(3); ?>
                <?php if($data): ?>
                sock.send(JSON.stringify({
                    section: 'vital3',
                    number: '<?php echo e($data->num); ?>',
                    priority: '<?php echo e($data->priority); ?>'
                }));
                <?php else: ?>
                sock.send(JSON.stringify({
                    section: 'vital3',
                    number: '&nbsp;'
                }));
                <?php endif; ?>

                sock.send(JSON.stringify({
                    section: 'consultation',
                    channel: 'addNumber'
                }));
            }
            <?php endif; ?>
        };

        sock.onmessage = function(event) {
            var data = JSON.parse(event.data);
            if(data.channel=='addNumber' && data.section=='vital'){
                $.get(
                    '<?php echo e(url('patient/count/2')); ?>',
                    function(data){
                        console.log(data);
                        $('.badge').html('Waiting: ' + data);
                    }
                );
            }
        };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>