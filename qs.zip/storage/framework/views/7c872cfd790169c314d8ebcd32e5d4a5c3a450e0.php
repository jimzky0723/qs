<?php
$status = session('status');
$section = array(
    'registration',
    'card',
    'vital',
    'pedia',
    'im',
    'surgery',
    'ob',
    'dental',
    'bite'
);

?>

<?php $__env->startSection('content'); ?>
    <style>
        .title-header {
            font-weight: normal;
            border-bottom: 1px solid #ccc;
        }
        .table-access td {
            padding: 2px 6px;
            vertical-align: middle;
        }
        .table-access td label {
            margin-top: 8px;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="top-campaign">
                <?php if($status=='created'): ?>
                    <div class="alert alert-success">
                        <i class="fa fa-check"></i> User access added successfully!
                    </div>
                <?php endif; ?>
                <?php if($status=='updated'): ?>
                    <div class="alert alert-info">
                        <i class="fa fa-check"></i> User access updated successfully!
                    </div>
                <?php endif; ?>
                <h3 class="title-3 m-b-30">
                    User Priviledges
                    <div class="pull-right">
                        <form method="POST" action="<?php echo e(url('settings/access')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <input type="text" name="keyword" placeholder="enter keyword . . ." class="form-control" value="<?php echo e(\Illuminate\Support\Facades\Session::get('accessKeyword')); ?>">
                                <div class="input-group-btn">
                                    <button class="btn btn-success" type="submit">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </h3>
                <?php if(count($data) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped" style="border:1px solid #ccc;">
                            <thead class="bg-dark" style="color:#fff;">
                            <tr>
                                <th>Complete Name</th>
                                <th class="text-center">Registration</th>
                                <th class="text-center">Card<br />Issuance</th>
                                <th class="text-center">Vital<br />Signs</th>
                                <th class="text-center">Pedia</th>
                                <th class="text-center">IM</th>
                                <th class="text-center">Surgery</th>
                                <th class="text-center">OB</th>
                                <th class="text-center">Dental</th>
                                <th class="text-center">Animal<br />Bite</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $access = \App\Http\Controllers\AdminCtrl::getAccess($row->id);
                            ?>
                            <tr>
                                <td>
                                    <a href="#updateInfo" data-toggle="modal" data-id="<?php echo e($row->id); ?>">
                                        <i class="fa fa-edit"></i>
                                        <?php echo e($row->lname); ?>, <?php echo e($row->fname); ?>

                                    </a>
                                </td>
                                <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-center">
                                    <?php if($access->$row): ?>
                                        <i class="fa fa-check text-success"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times text-danger"></i>
                                    <?php endif; ?>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <br />
                    <div class="text-center">
                        <?php echo e($data->links()); ?>

                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        No user found!
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<div class="modal fade" id="updateInfo" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(url('settings/access/update')); ?>" class="form-horizontal">
                <div class="modal-body">
                    <h3 class="title-header">
                        Access Level
                    </h3>
                    <br />
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="userId" id="userId" value="" />
                    <table class="table table-bordered table-access switchArea">
                        <tr>
                            <td>Loading...</td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-sm btn-success">
                        <i class="fa fa-check"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<script>
    $('a[href="#updateInfo"]').on('click',function(){
        var id = $(this).data('id');
        $('#userId').val(id);
        var content = '';
        <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var equiv = "<?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row)); ?>";
            var section = "<?php echo e($row); ?>";

            content += '<tr>\n' +
                '<td class="text-right bg-dark" style="color:#fff;">'+equiv+'</td>\n' +
                '<td class="text-center">\n' +
                '     <label class="switch switch-text switch-primary" id="'+section+'">\n' +
                '        <input type="checkbox" class="switch-input" checked="true" name="<?php echo e($row); ?>">\n' +
                '       <span data-on="On" data-off="Off" class="switch-label"></span>\n' +
                '        <span class="switch-handle"></span>\n' +
                '    </label>\n' +
                '    </td>\n' +
                ' </tr>';
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        $('.switchArea').html(content);

        $.get(
            "<?php echo e(url('settings/access/get')); ?>/"+id,
            function (data){
                var content = '';
                <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    var val = data<?php echo e('.'.$row); ?>;
                    var equiv = "<?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row)); ?>";
                    var stats = $('checkbox[name="<?php echo e($row); ?>"]');

                    if(val==0)
                    {
                        $("#<?php echo e($row); ?>").click();
                    }

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                //$('.switchArea').html(content);
            }
        );
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>