<?php $__env->startSection('content'); ?>
    <h3 class="text-center">Content goes here!</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>