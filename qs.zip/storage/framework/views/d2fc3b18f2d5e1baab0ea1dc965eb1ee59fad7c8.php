<script>
    alert();
</script>