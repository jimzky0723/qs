<?php
$status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <style>
        .names {
            text-transform: uppercase;
        }
        .pricing-table-features>li {
            font-size: 14px;
            font-weight: 300;
            line-height: 22px;
        }
        .pricing-table-features {
            margin: 0 0 10px;
            padding: 0;
            list-style: none;
        }
    </style>
    <div class="main-content container">
        <?php if($status=='added'): ?>
        <div role="alert" class="alert alert-success alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-check"></span></div>
            <div class="message"><strong>Added!</strong> You are now serving <?php echo e($current->fname); ?> <?php echo e($current->lname); ?>.</div>
        </div>
        <?php elseif($status=='notAvailable'): ?>
        <div role="alert" class="alert alert-danger alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-close"></span></div>
            <div class="message"><strong>Error!</strong> Please complete transaction with your patient.</div>
        </div>
        <?php elseif($status=='pending'): ?>
        <div role="alert" class="alert alert-warning alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-attention"></span></div>
            <div class="message"><strong>Pending!</strong> Added to 'Pending List'.</div>
        </div>
        <?php elseif($status=='ready'): ?>
        <div role="alert" class="alert alert-info alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-info"></span></div>
            <div class="message"><strong>Done!</strong> Accept new patient.</div>
        </div>
        <?php elseif($status=='error'): ?>
        <div role="alert" class="alert alert-danger alert-dismissible">
            <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="s7-close"></span></button>
            <div class="icon"><span class="s7-close"></span></div>
            <div class="message"><strong>Error!</strong> There is a problem processing your data.</div>
        </div>
        <?php endif; ?>

        <div class="row">
            <?php if($current): ?>
            <div class="col-sm-3">
                <div class="pricing-table">
                    <div class="pricing-table-title">Now Serving...</div>
                    <div class="pricing-table-price"><span class="value"><?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($current->section)); ?><?php echo e($current->num); ?></span></div>
                    <div class="panel-divider panel-divider-xl"></div>
                    <ul class="pricing-table-features">
                        <li class="names"><b><?php echo e($current->lname); ?>, <?php echo e($current->fname); ?></b></li>
                        <li><b>Hospital # :</b> <?php echo e(($current->hospitalNum==null) ? 'N/A': $current->hospitalNum); ?></li>
                        <li><b>Section :</b> <?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($current->section)); ?></li>
                    </ul>
                    <a href="<?php echo e(url('patient/card/done/'.$current->id)); ?>" class="btn btn-primary btn-block">Done</a>
                    <button class="btn btn-info btn-block" data-priority="<?php echo e($current->priority); ?>" data-num="<?php echo e($current->num); ?>" id="notify">Notify</button>
                    <button data-link="<?php echo e(url('patient/card/cancel/'.$current->id)); ?>" data-modal="modal-cancel" class="btn btn-space btn-warning btn-big md-trigger btn-block btn-cancel">Cancel</button>

                </div>
            </div>
            <?php endif; ?>
            <div class="<?php echo e((isset($current)) ? 'col-sm-9' : 'col-sm-12'); ?>">

                <div class="panel panel-default">
                    <div class="panel-heading">Card Issuance</div>
                    <div class="panel-body">
                        <?php if(count($data) > 0): ?>
                        <table class="table table-sm table-hover table-bordered table-striped">
                            <thead>
                            <tr>
                                <th class="text-center">Priority #</th>
                                <th>Last Name</th>
                                <th>First Name</th>
                                <th>Hospital #</th>
                                <th>Section</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center <?php echo e(($row->priority==1) ? 'text-success':''); ?>">
                                        <?php if($row->priority==1): ?>
                                            <span class="text-success"><i class="fa fa-wheelchair"></i></span>
                                        <?php endif; ?>
                                        <?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($row->section)); ?><?php echo e($row->num); ?>

                                    </td>
                                    <td class="names"><?php echo e($row->lname); ?></td>
                                    <td class="names"><?php echo e($row->fname); ?></td>
                                    <td><?php echo e($row->hospitalNum); ?></td>
                                    <td><?php echo e(\App\Http\Controllers\AbbrCtrl::equiv($row->section)); ?></td>
                                    <?php if($row->status=='ready'): ?>
                                        <td class="text-success">
                                            for verification
                                        </td>
                                    <?php else: ?>
                                        <td class="text-danger">
                                            <?php echo e($row->status); ?>

                                        </td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('patient/card/submit/'.$row->id)); ?>" class="btn btn-success btn-sm">
                                            <small><i class="fa fa-check"></i> Verified</small>
                                        </a>
                                        <a href="<?php echo e(url('patient/card/pending/'.$row->id)); ?>" class="btn btn-warning btn-sm">
                                            <small><i class="fa fa-refresh"></i> Pending</small>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>

                            <div role="alert" class="alert alert-warning">
                                <div class="icon"><span class="s7-attention"></span></div>
                                <div class="message">No patients available!</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });

    </script>

    <?php if($current): ?>
        <script>
            sock.onopen = function() {
                sock.send(JSON.stringify({
                    section: 'card',
                    number: '<?php echo e(\App\Http\Controllers\NumberCtrl::initialSection($current->section)); ?><?php echo e($current->num); ?>',
                    priority: '<?php echo e($current->priority); ?>'
                }));

                sock.send(JSON.stringify({
                    channel: 'pending'
                }));
            };
        </script>
    <?php else: ?>
        <script>
            sock.onopen = function() {
                sock.send(JSON.stringify({
                    section: 'card',
                    number: '&nbsp;'
                }));

                sock.send(JSON.stringify({
                    section: 'vital',
                    channel: 'addNumber'
                }));

                sock.send(JSON.stringify({
                    channel: '<?php echo e($status); ?>'
                }));
            };
        </script>
    <?php endif; ?>

    <script>
        $('body').on('click','#notify',function(){
            location.reload();
        });
    </script>
    <?php echo $__env->make('script.cancel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>