<?php
    $status = session('status');
?>

<?php $__env->startSection('content'); ?>
    <div class="main-content container">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">Pending Patients
                    <div class="tools">
                        <form method="POST" action="<?php echo e(url('patient/pending')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group mb-2">
                                <input type="text" class="form-control" name="keyword" placeholder="enter keyword . . ." value="<?php echo e(\Illuminate\Support\Facades\Session::get('pendingKeyword')); ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary"><span class="s7-search"></span> Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel-body">
                    <?php if(count($data) > 0): ?>
                        <table class="table table-sm table-hover table-bordered table-striped">
                            <thead class="table-primary">
                            <tr>
                                <th>Complete Name</th>
                                <th>Date of Birth</th>
                                <th class="text-center">Priority #</th>
                                <th class="text-center">Current</th>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->lname); ?>, <?php echo e($row->fname); ?></td>
                                <td><?php echo e(date('M d, Y',strtotime($row->dob))); ?></td>
                                <td class="text-center"><?php echo e($row->num); ?></td>
                                <td class="text-center"><?php echo e($row->currentStep); ?></td>
                                <td class="text-center">
                                    <button class="btn btn-rounded btn-space btn-info btn-xs">
                                        <i class="icon icon-left s7-shuffle"></i> Forward To
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr />
                        <div class="text-center">
                            <?php echo e($data->links()); ?>

                        </div>
                    <?php else: ?>
                        <div role="alert" class="alert alert-warning alert-dismissible">
                            <div class="icon"><span class="s7-attention"></span></div>
                            <div class="message"><strong>Warning!</strong> No patient found.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="updateInfo" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(url('settings/access/update')); ?>" class="form-horizontal">
                    <div class="modal-body">
                        <h3 class="title-header">
                            Access Level
                        </h3>
                        <br />
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="userId" id="userId" value="" />
                        <table class="table table-bordered table-access switchArea">
                            <tr>
                                <td>Loading...</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-block btn-sm btn-success">
                            <i class="fa fa-check"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            //initialize the javascript
            App.init();
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            App.livePreview();
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tdhlayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>