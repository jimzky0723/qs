<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from foxythemes.net/preview/products/maisonnette/pages-blank.php?theme=default by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Aug 2018 01:29:56 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="<?php echo e(url('resources/tdh/')); ?>/img/favicon.png">
    <title><?php echo e((isset($title)) ? $title: 'Talisay District Hospital'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/tdh/')); ?>/lib/stroke-7/style.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/tdh/')); ?>/lib/perfect-scrollbar/css/perfect-scrollbar.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/tdh/')); ?>/lib/theme-switcher/theme-switcher.min.css"/><link type="text/css" href="<?php echo e(url('resources/tdh/')); ?>/css/app.css" rel="stylesheet">  </head>
<body>
<nav class="navbar navbar-expand navbar-dark mai-top-header">
    <div class="container"><a href="#" class="navbar-brand"></a>
        <!--Left Menu-->
        <ul class="nav navbar-nav mai-top-nav">

        </ul>
        <!--Icons Menu-->
        <ul class="navbar-nav float-lg-right mai-icons-nav">


        </ul>
        <!--User Menu-->
        <ul class="nav navbar-nav float-lg-right mai-user-nav">
            <li class="dropdown nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="dropdown-toggle nav-link"> <img src="<?php echo e(url('resources/tdh/')); ?>/img/avatar.jpg"><span class="user-name">Jimmy Parker</span><span class="angle-down s7-angle-down"></span></a>
                <div role="menu" class="dropdown-menu">
                    <a href="#" class="dropdown-item"> <span class="icon s7-tools"> </span>Account Settings</a>
                    <a href="#" class="dropdown-item"> <span class="icon s7-unlock"> </span>Change Password</a>
                    <a href="#" class="dropdown-item"><span class="icon s7-power"> </span>Log Out</a></div>
            </li>
        </ul>
    </div>
</nav>
<div class="mai-wrapper">
    <?php echo $__env->make('layout.menu2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-content container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<script src="<?php echo e(url('resources/tdh/')); ?>/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('resources/tdh/')); ?>/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('resources/tdh/')); ?>/lib/bootstrap/dist/js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('resources/tdh/')); ?>/js/app.js" type="text/javascript"></script>
<script src="<?php echo e(url('resources/tdh/')); ?>/lib/theme-switcher/theme-switcher.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function(){
        //initialize the javascript
        App.init();
    });

</script>
<script type="text/javascript">
    $(document).ready(function(){
        App.livePreview();
    });

</script>
<?php echo $__env->yieldContent('script'); ?>
</body>

<!-- Mirrored from foxythemes.net/preview/products/maisonnette/pages-blank.php?theme=default by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Aug 2018 01:29:56 GMT -->
</html>